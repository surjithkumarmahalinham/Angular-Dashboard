export class PositionModel {
  constructor(
    public lat = 53.9,
    public lng = 27.5667,
  ) {}
}
